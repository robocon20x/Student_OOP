#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif
#pragma once
#include<iostream>
#include<cmath>
#include<vector>
#include<string>
#include<sstream>
#include<ctime>
#include<iomanip>
#include<time.h>


using namespace std;

class Util {
public:
	static void print(int value);
};


class Random {
public:
	static bool _seeded;
public:
	static int nextInt();
	static int nextInt(int ceiling);
	static int nextInt(int left, int right);
};

class Interger {
public:
	static bool Is_Prime(int a);
	static int GDC(int a, int b);
};
class Dice {
public:
	static int roll();
};


class DynamicArray {
private:
	int* _a;
	int _currentSize;
	int _bufferSize;
public:
	int size();
	int getAt(int i);
	void push_back(int item);
	DynamicArray(int initialSize);
	~DynamicArray();
	int operator [] (int index);
};

class Tokenizer {
public:
	static vector<string> spilt(string haystack, string needle);
	static string tolower_str(string);
};

class MobileNetwork {
private:
	string _name;
	vector<string> _prefixes;
public:
	string name();
	void setName(string);
	vector<string> prefixes();
public:
	MobileNetwork();
	MobileNetwork(string name, vector<string> prefixes);
};

class Telephone {
private:
	MobileNetwork _network;
	string _prefix;
	string _number;
public:
	MobileNetwork network();
	string number();
	string toString();
	Telephone(MobileNetwork network, string prefix, string number);
	Telephone(string);
	Telephone();
};

class Fullname {
private:
	string _firstname;
	string _middlename;
	string _lastname;
public:
	string toString();

	void setFirstname(string);
	string getFirstname();

	void setMiddlename(string);
	string getMiddlename();

	void setLastname(string);
	string getLastname();
	Fullname();
	Fullname(string);
	Fullname(string, string, string);
};

class Email
{
private:
	string _first;
	string _middle;
	string _last;
	string _domain;
public:
	Email();

	Email(string s);

	Email(string first, string middle, string last, string domain);

	string toString();

	string domain();

};

class Address {
private:
	string _number;
	string _street;
	string _ward;
	string _district;
	string _city;
public:
	string toString();
	Address(string, string, string, string, string);
	Address(string);
	Address();
	string district();
};

class DateTime {
private:
	int _day;
	int _month;
	int _year;
public:
	string toString();
	DateTime(int, int, int);
	DateTime(string);
	DateTime();
	static int currentYear();
	static bool isLeapYear(int);
	int day();
	int month();
	int year();
};

class Student
{
private:
	string _id;
	Fullname _name;
	string _citizenId;
	Telephone _telephone;
	Email _email;
	Address _address;
	DateTime _dateTime;
public:
	Student() {}

	Student(string id, Fullname name, string citizenId, Telephone telephone, Email email, Address address, DateTime dateTime);

	string getid();
	void setid(string);

	Fullname getname();
	void setname(Fullname);

	string getcitizenId();
	void setcitizenId(string);

	Telephone gettele();
	void settele(Telephone);

	Email getemail();
	void setemail(Email);

	Address getaddress();
	void setaddress(Address);

	DateTime datetime();
	void setdateTime(DateTime);

	string toString();


};

class FindStudent {
private:
	vector<Student> _student;
public:
	FindStudent(string filename);
	void findBirthMonth(int month);
	void findTelephone(string network);
	void findEmail(string domain);
	void findAddress(string district);
};