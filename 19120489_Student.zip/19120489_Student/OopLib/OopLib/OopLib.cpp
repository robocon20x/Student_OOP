#include"OopLib.h"
#include<fstream>

void Util::print(int value) {
	cout << value;
}

bool Random::_seeded;

int Random::nextInt() {
	if (_seeded == false) {
		srand(time(NULL));
		_seeded = true;
	}
	return rand();
}
int Random::nextInt(int ceiling) {
	if (_seeded == false) {
		srand(time(NULL));
		_seeded = true;
	}
	return rand() % (ceiling);
}
int Random::nextInt(int left, int right) {
	if (_seeded == false) {
		srand(time(NULL));
		_seeded = true;
	}
	return left + rand() % (right - left + 1);
}

int Interger::GDC(int a, int b) {
	/*while (a * b != 0) {
		if (a > b) a %= b;
		else b %= a;
	}
	return a + b;*/
	if (a == 0)
		return b;
	else if (b == 0)
		return a;
	else
	{
		while (a != b)
		{
			if (a > b) a = a - b;
			else b = b - a;
		}
		return a;
	}
}
bool Interger::Is_Prime(int n) {

	if (n < 2) return false;
	if (n == 2) return true;
	for (int i = 2; i <= sqrt(n); i++) {
		if (n % i == 0) return false;
	}
	return true;
}

int Dice::roll() {
	Random rand;
	return rand.nextInt(1, 6);
}

int DynamicArray::size() {
	return _currentSize;
}

int DynamicArray::getAt(int i) {
	if (i < _currentSize) {
		return _a[i];
	}
	else {
		cout << "\n Index out of bound.\n";
		return NULL;
	}
}

void DynamicArray::push_back(int item) {
	const int STEP = 5;
	if (_currentSize == _bufferSize) {
		int newSize = _currentSize + STEP;
		int* temp = new int[newSize];

		for (int i = 0; i < _currentSize; i++) {
			temp[i] = _a[i];
		}

		delete[] _a;

		_a = temp;

	}

	_a[_currentSize] = item;
	_currentSize++;
}

DynamicArray::DynamicArray(int initialSize) {
	_currentSize = 0;
	_a = new int[initialSize];
	_bufferSize = initialSize;
}

DynamicArray::~DynamicArray() {
	cout << "\nDestructor called" << endl;
	delete[] _a;
}

int DynamicArray:: operator [](int index) {
	return getAt(index);
}

vector<string> Tokenizer::spilt(string haystack, string needle) {
	vector<string> result;
	int startPos = 0;
	size_t foundPos = 0;

	while (true) {
		foundPos = haystack.find(needle, startPos);

		if (foundPos != string::npos) {
			string token = haystack.substr(startPos, foundPos - startPos);
			result.push_back(token);
			startPos = foundPos + needle.length();
		}
		else {
			string token = haystack.substr(startPos, haystack.length() - startPos);
			result.push_back(token);
			break;
		}
	}
	return result;
}

string Tokenizer::tolower_str(string buffer) {
	char c;
	int i = 0;
	string result;
	while (buffer[i]) {
		result += (char)tolower((int)buffer[i]);
		i++;
	}
	return result;
}

// tra ve ten nha mang 
string MobileNetwork::name() {
	return _name;
}
// tra ve so nha mang
vector<string> MobileNetwork::prefixes() {
	return _prefixes;
}

MobileNetwork::MobileNetwork() {
	//
}
// Khoi tao ten nha mang co dau so
MobileNetwork::MobileNetwork(string name, vector<string> prefixes) {
	_name = name;
	_prefixes = prefixes;
}

// tra ve ten nha mang network
MobileNetwork Telephone::network() {
	return _network;
}

void MobileNetwork::setName(string name) {
	_name = name;
}
// tra number cua class Telephone
string Telephone::number() {
	return _number;
}
// tra ve chuoi so dien thoai
string Telephone::toString() {
	stringstream ss;
	ss << _network.name()<<":"<<_prefix << _number;
	string s;
	s = ss.str();
	return s;
}
//khoi tao bien telephone
Telephone::Telephone(MobileNetwork network, string prefix, string number) {
	_network = network;
	_prefix = prefix;
	_number = number;
}
Telephone::Telephone() {}
Telephone::Telephone(string buffer) {
	vector<string> tokens = Tokenizer::spilt(buffer, ":");

	_network.setName(tokens[0]);
	
	_prefix = tokens[1].substr(0, 3);
	_number = tokens[1].substr(3);
}
// tra ve chuoi string fullname
string Fullname::toString() {
	stringstream ss;
	ss << _firstname << " " << _middlename << " " << _lastname;
	string s = ss.str();
	return s;
}
//chinh sua firstname
void Fullname::setFirstname(string firstname) {
	_firstname = firstname;
}
//lay ra firstname
string Fullname::getFirstname() {
	return _firstname;
}
// chinh sua middlename
void Fullname::setMiddlename(string middlename) {
	_middlename = middlename;
}
//lay ra middle name
string Fullname::getMiddlename() {
	return _middlename;
}
// chinh sua lastname
void Fullname::setLastname(string lastname) {
	_lastname = lastname;
}
//lay ra lastname
string Fullname::getLastname() {
	return _lastname;
}
//khoi tao fullname
Fullname::Fullname() {}
Fullname::Fullname(string firstname, string middlename, string lastname) {
	_firstname = firstname;
	_middlename = middlename;
	_lastname = lastname;
}
Fullname::Fullname(string buffer) {
	vector<string> tokens = Tokenizer::spilt(buffer, " ");
	_firstname = tokens[0];
	_middlename = tokens[1];
	_lastname = tokens[2];
}

Email::Email() {}
Email::Email(string buffer)
{
	vector<string> tokens = Tokenizer::spilt(buffer, "@");


	_first = tokens[0].substr(0, 1);

	_middle = tokens[0].substr(1, 1);

	_last = tokens[0].substr(2);

	_domain = tokens[1];
}

Email::Email(string first, string middle, string last, string domain)
{
	_first = first;
	_middle = middle;
	_last = last;
	_domain = domain;
}

string Email::toString()
{
	stringstream writer;
	writer << _first << _middle << _last << "@" << _domain;

	string email = writer.str();

	return email;
}

string Email::domain()
{
	return _domain;
}



//chuyen dia chi thanh mang string
string Address::toString() {
	stringstream writers;
	writers << _number << "/" << _street << "/" << _ward << "/" << _district << "/" << _city;
	string address;
	address = writers.str();
	return address;
}
Address::Address() {}

Address::Address(string buffer) {
	vector<string> tokens = Tokenizer::spilt(buffer, "/");
	_number = tokens[0];
	_street = tokens[1];
	_ward = tokens[2];
	_district = tokens[3];
	_city = tokens[4];
}

Address::Address(string number, string street, string ward, string district,string city) {
	_number = number;
	_street = street;
	_ward = ward;
	_district = district;
	_city = city;
}

string Address::district() {
	return _district;
}	

string DateTime::toString() {
	stringstream write;
	write << setw(2) << setfill('0') << _day << "/";
	write << setw(2) << setfill('0') << _month << "/";
	write << _year;
	string result = write.str();
	return result;
}

DateTime::DateTime(int day, int month, int year) {
	_day = day;
	_month = month;
	_year = year;
}
DateTime::DateTime() {}

DateTime::DateTime(string buffer) {
	vector<string> tokens = Tokenizer::spilt(buffer, "/");
	_day = stoi(tokens[0]);
	_month = stoi(tokens[1]);
	_year = stoi(tokens[2]);
}

int DateTime::currentYear() {

	time_t now = time(0);
	tm* ltm = localtime(&now);
	int result = 1900 + ltm->tm_year;

	return result;
}

bool DateTime::isLeapYear(int year) {
	if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)) return true;
	return false;
}

int DateTime::day() { return _day; }
int DateTime::month() { return _month; }
int DateTime::year() { return _year; }

Student::Student(string id, Fullname name, string citizenId, Telephone telephone, Email email, Address address, DateTime dateTime)
{
	_id = id;
	_name = name;
	_citizenId = citizenId;
	_telephone = telephone;
	_email = email;
	_address = address;
	_dateTime = dateTime;
}


string Student::getid() { return _id; }

Fullname Student::getname() { return _name; }

string Student::getcitizenId() { return _citizenId; }

Telephone Student::gettele() { return _telephone; }

Email Student::getemail() { return _email; }

Address Student::getaddress() { return _address; }

DateTime Student::datetime()
{
	return _dateTime;
}



string Student::toString()
{
	stringstream writer;

	writer << _id << endl;
	writer << _name.toString() << endl;
	writer << _citizenId << endl;
	writer << _telephone.toString() << endl;
	writer << _email.toString() << endl;
	writer << _address.toString() << endl;
	writer << _dateTime.toString() << endl;

	return writer.str();
}

FindStudent::FindStudent(string filename)
{
	int n;
	string buffer;
	ifstream read(filename);

	read >> n;
	read.ignore();

	for (int i = 0; i < n; i++)
	{
		getline(read, buffer);
		string id = buffer;
		getline(read, buffer);
		Fullname name(buffer);
		getline(read, buffer);
		string citizenId = buffer;
		getline(read, buffer);
		Telephone tele(buffer);
		getline(read, buffer);
		Email email(buffer);
		getline(read, buffer);
		Address address(buffer);
		getline(read, buffer);
		DateTime birth(buffer);
		Student student(id, name, citizenId, tele, email, address, birth);
		_student.push_back(student);
	}
}

void FindStudent::findBirthMonth(int month)
{
	DateTime datetime;
	vector<int> save;
	for (int i = 0; i < _student.size(); i++)
	{
		datetime = _student[i].datetime();
		if (datetime.month() == month) save.push_back(i);
			
	}
	cout << "Co " << save.size() << " Student sinh vao thang " << month <<":"<< endl;
	for (int i = 0; i < save.size(); i++)
	{
		cout << _student[save[i]].toString() << "-----------------------------" << endl;
	}
	
}

void FindStudent::findTelephone(string network)
{
	Telephone telephone;
	vector<int> save;
	for (int i = 0; i < _student.size(); i++)
	{
		telephone = _student[i].gettele();
		if (telephone.network().name() == network) save.push_back(i);
			
	}
	cout << "Co " << save.size() << " Student dung mang " << network << endl;
	for (int i = 0; i < save.size(); i++)
	{
		cout << _student[save[i]].toString() << "-----------------------------" << endl;
	}
}

void FindStudent::findEmail(string domain)
{
	Email email;
	vector<int> save;

	for (int i = 0; i < _student.size(); i++)
	{
		email = _student[i].getemail();
		if (email.domain() == domain) save.push_back(i);
	}
	cout << "Co " << save.size() << " Student dung domain " << domain << endl;
	for (int i = 0; i < save.size(); i++)
	{
		cout << _student[save[i]].toString() << "-----------------------------" << endl;
	}
}

void FindStudent::findAddress(string district)
{
	vector<int> save;
	Address address;

	for (int i = 0; i < _student.size(); i++)
	{
		address = _student[i].getaddress();
		if (address.district() == district) save.push_back(i);
	}
	cout << "Co " << save.size() << " Student o " << district << endl;
	for (int i = 0; i < save.size(); i++)
	{
		cout << _student[save[i]].toString() << "-----------------------------" << endl;
	}
}