
#include "MockRepoV1.h"
#include<string>
#include<fstream>


TelephoneMock::TelephoneMock() {
	// khoi tao cac nha mang va dau so 
	_supportedNetworks.push_back(MobileNetwork("Viettel", { "086", "096", "097", "098", "032", "033", "034", "035", "036", "037", "038", "039" }));
	_supportedNetworks.push_back(MobileNetwork("Vinaphone", { "088", "091", "094", "083", "084", "085", "081", "082" }));
	_supportedNetworks.push_back(MobileNetwork("Mobiphone", { "089", "090", "093", "070", "079", "077", "076", "078" }));
	_supportedNetworks.push_back(MobileNetwork("Vietnamobile", { "092", "056", "058" }));
	_supportedNetworks.push_back(MobileNetwork("GMobile", { "099", "059" }));
	_supportedNetworks.push_back(MobileNetwork("Itelecom", { "087" }));
}
Telephone TelephoneMock::next() {
	int rng1 = _rng.nextInt(_supportedNetworks.size());
	MobileNetwork network = _supportedNetworks[rng1]; // chon ngau nhien nha mang

	vector<string> prefixes = network.prefixes();
	int rng2 = _rng.nextInt(prefixes.size());
	string prefix = prefixes[rng2]; // chon ngau nhien dau so cua nha mang da chon o tren

	stringstream ss;
	for (int i = 0; i < 7; i++) {
		ss << _rng.nextInt(0, 10); // ngau nhien 7 so con lai
	}
	string numbers = ss.str(); // chuyen mang so dien thoai thanh string

	Telephone phonenumber(network, prefix, numbers);
	return phonenumber;
}


Fullname FullnameMock::next(bool male) {
	int a = _rng.nextInt(_firstname.size());
	string firstname = _firstname[a]; // chon ngau nhien first name
	string middlename;
	string lastname;
	//chon ngau nhien middlename va lastname theo gioi tinh
	if (male) {
		int b = _rng.nextInt(_maleMiddleNames.size());
		middlename = _maleMiddleNames[b];
		int c = _rng.nextInt(_maleLastNames.size());
		lastname = _maleLastNames[c];
	}
	else {
		int b = _rng.nextInt(_femaleMiddleNames.size());
		middlename = _femaleMiddleNames[b];
		int c = _rng.nextInt(_femaleLastNames.size());
		lastname = _femaleLastNames[c];
	}
	Fullname fullname(firstname, middlename, lastname);
	return fullname;
}

FullnameMock::FullnameMock() { // lay du lieu tu ngoai vao, bat buoc ten chinh phai di cung mot so ten phu
	ifstream read("fullname.txt");
	string buffer;
	getline(read, buffer);
	_firstname = Tokenizer::spilt(buffer, ",");

	getline(read, buffer);
	_maleMiddleNames = Tokenizer::spilt(buffer, ",");

	getline(read, buffer);
	_femaleMiddleNames = Tokenizer::spilt(buffer, ",");

	getline(read, buffer);
	_maleLastNames = Tokenizer::spilt(buffer, ",");

	getline(read, buffer);
	int n = 0;
	n = stoi(buffer);
	for (int i = 0; i < n; i++) { // thiet lap ten chinh di cung ten lot
		vector<int> temp1;

		getline(read, buffer);
		vector<string> temp;
		temp = Tokenizer::spilt(buffer, " ");

		for (int j = 0; j < temp.size(); j++) {
			int m = stoi(temp[j]);
			temp1.push_back(m);
		}
		_maleCompare.push_back(temp1);
	}

	getline(read, buffer);
	_femaleLastNames = Tokenizer::spilt(buffer, ",");
	getline(read, buffer);
	n = 0;
	n = stoi(buffer);
	for (int i = 0; i < n; i++) {
		vector<int> temp1;

		getline(read, buffer);
		vector<string> temp;
		temp = Tokenizer::spilt(buffer, " ");

		for (int j = 0; j < temp.size(); j++) {
			int m = stoi(temp[j]);
			temp1.push_back(m);
		}
		_femaleCompare.push_back(temp1);
	}
	read.close();
}

EmailMock::EmailMock() { // lay du lieu tu ngoai vao
	ifstream read("domains.txt");
	string buffer;
	while (getline(read, buffer)) {
		_domains.push_back(buffer);
	}
	read.close();
}

string EmailMock::next() {
	bool male = _rng.nextInt(2) == 1; // ngau nhien gioi tinh

	Fullname name = _nameStore.next(male); // khoi tao ngau nhien ten theo gioi tinh

	string email = next(name); // khoi tao email theo ten da duoc chon 

	return email;
}

string EmailMock::next(Fullname name) {

	string first = name.getFirstname().substr(0, 1); // Lay firstname sau do lay chu cai dau tien
	string middle = name.getMiddlename().substr(0, 1); // lay middlename sau do lay chu cai dau tien
	string lastname = name.getLastname(); // lay lastname

	int i = _rng.nextInt(_domains.size());
	string domain = _domains[i]; // chon ngay nhien domain tu vector duoc khoi tao o tren

	string email = "";

	stringstream writers;
	writers << first << middle << lastname << "@" << domain; // gop cac string dia chi 
	email = writers.str();
	string result = Tokenizer::tolower_str(email);
	return result;
}

HcmAddressMock::HcmAddressMock() { // khoi tao tu du lieu ben ngoai, co phan ra chinh xac tung quan, phuong
	string buffer;
	int districtsize, wardsize, streetsize;

	ifstream read("hcmaddresses.txt");
	read >> districtsize;
	read.ignore();

	_districts.resize(districtsize);
	_wards.resize(districtsize);
	_streets.resize(districtsize);

	for (int i = 0; i < districtsize; i++)
	{
		getline(read, buffer);
		_districts[i] = buffer;

		read >> wardsize;
		read.ignore();
		_wards[i].resize(wardsize);
		for (int j = 0; j < wardsize; j++)
		{
			getline(read, buffer);
			_wards[i][j] = buffer;
		}

		read >> streetsize;
		read.ignore();
		_streets[i].resize(streetsize);
		for (int j = 0; j < streetsize; j++)
		{
			getline(read, buffer);
			_streets[i][j] = buffer;
		}
	}

	read.close();
}

Address HcmAddressMock::next() { 
	string number = to_string(_rng.nextInt(200)); // ngau nhien so nha 

	string city = "Ho Chi Minh";

	int i = _rng.nextInt(_districts.size()); // ngau nhien quan
	string district = _districts[i];

	int j = _rng.nextInt(_streets[i].size()); // ngau nhien duong tu quan duoc chon
	string street = _streets[i][j];

	int k = _rng.nextInt(_wards[i].size()); // ngau nhien ward tu quan duoc chon
	string ward = _wards[i][k];

	Address address(number, street, ward, district, city); // khoi tao bien address bang cac du lieu chon ra o tren

	return address;
}

BirthDayMock::BirthDayMock() {
	_maxAge = 120;
	_minAge = 18;
	_currentYear = DateTime::currentYear();
}

DateTime BirthDayMock::next() { // khoi tao ngay sinh, do o day la sinh vien nen cho tuoi nho nhat la 18

	int year = _currentYear - _rng.nextInt(_minAge, _maxAge);
	int month = _rng.nextInt(1, 12);
	int days[] = { -1,31,28,31,30,31,30,31,31,30,31,30,31 };

	if (DateTime::isLeapYear(year)) {
		days[2] = 29;
	}

	int day = _rng.nextInt(days[month]);

	DateTime result(day, month, year);
	return result;
}

CitizenMock::CitizenMock() { 
	_cityCodes = { "001","002","004","006","008","010","011","012","014","015","017","019","020","022","024","025","026","027","030","031","033","034","035","036","037","038","040","042","044","045","046","048","049","051","052","054","056","058","060","062","064","066","067","068","070","072","074","075","077","079","080","082","083","084","086","087","089","091","092","093","094","095","096" };
	_cityNames = { "Ha Noi","Ha Giang","Cao Bang","Bac Kan","Tuyen Quang","Lao Cai","Dien Bien","Lai Chau","Son La","Yeu Bai","Hoa Binh","Thai Nguyen","Lang Son","Quang Ninh","Bac Giang","Phu Tho","Vinh Phuc","Bac Ninh","Hai Duong","Hai Phong","Hung Yen","Thai Binh","Ha Nam","Nam Dinh","Ninh Binh","Thanh Hoa","Nghe An","Ha Tinh","Quang Binh","Quang Tri","Thua Thin Hue","Da Nang","Quang Nam","Quang Ngai","Binh Dinh","Phu Yen","Khanh Hoa","Ninh Thuan","Binh Thuan","Kon Tum","Gia Lai","Dak Lak","Dak Nong","Lam Dong","Binh Phuoc","Tay Ninh","Binh Duong","Dong Nai","Ba Ria- Vung Tau","Ho Chi Minh","Long An","Tien Giang","Ben Tre","Tra Vinh","Vinh Long","Dong Thap","An Giang","Kien Giang","Can Tho","Hau Giang","Soc Trang","Bac Lieu","Ca Mau" };
	_maxAge = 120;
	_currentYear = DateTime::currentYear();
	_male = true;
}

string CitizenMock::next() {// tao ngau nhien 
	stringstream writer;

	int i = _rng.nextInt(_cityCodes.size());
	string cityCode = _cityCodes[i];

	int birthYear = _currentYear - _rng.nextInt(_maxAge);

	int birth = birthYear % 100;

	int century = birthYear / 100 + 1;

	int male = _rng.nextInt(0, 1);
	int gender = (century - 20) * 2 + male;

	writer << cityCode << gender;

	if (birth < 10) {
		writer << "0";
	}
	writer << birth;

	for (int i = 0; i < 6; i++) {
		writer << _rng.nextInt(10);
	}

	string result = writer.str();
	return result;
}

string CitizenMock::next(bool male) { // tao theo gioi tinh

	stringstream writer;

	int i = _rng.nextInt(_cityCodes.size());
	string cityCode = _cityCodes[i];

	int birthYear = _currentYear - _rng.nextInt(_maxAge);

	int birth = birthYear % 100;

	int century = birthYear / 100 + 1;

	int numbermale;
	if (male == true) numbermale = 0;
	else numbermale = 1;

	int gender = (century - 20) * 2 + numbermale;

	writer << cityCode << gender;

	if (birth < 10) {
		writer << "0";
	}
	writer << birth;

	for (int i = 0; i < 6; i++) {
		writer << _rng.nextInt(10);
	}

	string result = writer.str();
	return result;
}

string CitizenMock::info(string citizencode) { // lay thong tin tu cccd da co san
	stringstream writer;
	string citycode_s = citizencode.substr(0, 3);

	int code = -1;
	for (int i = 0; i < _cityCodes.size(); i++) {
		if (citycode_s == _cityCodes[i]) {
			code = i;
			break;
		}
	}

	string gender = citizencode.substr(3, 1);
	int male = -1;
	if (stoi(gender) % 2 == 0) male = 0;
	else male = 1;
	string birthyear_s = citizencode.substr(4, 2);
	int birthyear_i = (((stoi(gender) - male) / 2 + 20) - 1) * 100 + stoi(birthyear_s);
	string sex;
	if (male == 0) sex = "nam";
	else sex = "nu";
	writer << "Tinh,Thanh Pho: " << _cityNames[code] << ", Gioi Tinh: " << sex << ", Nam Sinh " << birthyear_i;
	string result = writer.str();
	return result;
}

StudentIdMock::StudentIdMock() { // tao id
	_year = { "15", "16", "17", "18", "19", "20","21" };
	_sub = { "11", "12", "13", "14", "15", "16", "17" ,"18","19","20" };
}
string StudentIdMock::next() { // tao ngau nhie id 
	string year;
	string sub;

	int i = _rng.nextInt(_year.size());
	year = _year[i];

	i = _rng.nextInt(_sub.size());
	sub = _sub[i];

	stringstream writer;
	writer << year << sub;
	for (int j = 0; j < 4; j++) {
		i = _rng.nextInt(10);
		writer << i;
	}
	
	return writer.str();
}
StudentMock::StudentMock() {}

Student StudentMock::next() { // tao ngau nhien sinh vien 
	
	string id = _id.next();

	bool male = ((Random::nextInt(2) / 2) == 0); // ngau nhien gioi tinh, va su dung nhung hang ngau nhien da co o tren

	Fullname name = _name.next(male);

	string citizenId = _citizenId.next();

	Telephone tele = _tele.next();

	Email email = _email.next(name);

	Address address = _address.next();

	DateTime birth = _birth.next();

	Student student(id, name, citizenId, tele, email, address, birth);

	return student;
}