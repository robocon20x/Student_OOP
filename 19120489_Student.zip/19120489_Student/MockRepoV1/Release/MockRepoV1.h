#include"OopLib.h"


class TelephoneMock {
private:
	vector<MobileNetwork> _supportedNetworks;
	Random _rng;
public:
	TelephoneMock();
	Telephone next();
};

class FullnameMock {
private:
	Random _rng;
	vector<string> _femaleMiddleNames;
	vector<string> _femaleLastNames;
	vector<string> _maleMiddleNames;
	vector<string> _maleLastNames;
	vector<vector<int>> _maleCompare;
	vector<vector<int>> _femaleCompare;
	vector<string> _firstname;
public:
	Fullname next(bool);
	FullnameMock();
};

class EmailMock {
private:
	Random _rng;
	vector<string> _domains;
	FullnameMock _nameStore;
public:
	string next();
	EmailMock();
	string next(Fullname name);
};

class HcmAddressMock {
private:
	Random _rng;
	vector<vector<string>> _streets;
	vector<vector<string>> _wards;
	vector<string> _districts;
public:
	HcmAddressMock();
	Address next();
};

class BirthDayMock {
private:
	Random _rng;
	int _maxAge;
	int _currentYear;
	int _minAge;
public:
	BirthDayMock();
	DateTime next();
};

class CitizenMock {
private:
	Random _rng;
	vector<string> _cityCodes;
	vector<string> _cityNames;
	bool _male;
	int _maxAge;
	int _currentYear;
public:
	CitizenMock();
	string next();
	string next(bool);
	string info(string);
};

class StudentIdMock
{
private:
	Random _rng;
	vector<string> _year;
	vector<string> _sub;
public:
	StudentIdMock();
	string next();
};

class StudentMock
{
private:
	Random _rng;

	StudentIdMock _id;
	FullnameMock _name;
	CitizenMock _citizenId;
	TelephoneMock _tele;
	EmailMock _email;
	HcmAddressMock _address;
	BirthDayMock _birth;
public:
	StudentMock();

	Student next();
};