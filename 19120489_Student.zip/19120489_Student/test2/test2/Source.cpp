﻿#include <iostream>
#include "MockRepoV1.h"
#include<fstream>
#include"OopLib.h"
using namespace std;

int main()
{

	int n = Random::nextInt(5, 20);

	StudentMock studentmock;
	vector<Student> student;

	for (int i = 0; i < n; i++)
	{
		student.push_back(studentmock.next());
	}

	// ghi ra file
	ofstream write("Student.txt");
	write << n << endl;

	for (int i = 0; i < n; i++)
	{
		write << student[i].toString();
	}

	write.close();

	// doc file va thao tac voi du lieu tra loi cac cau hoi 
	FindStudent findStudent("Student.txt");
	
	findStudent.findBirthMonth(2);

	findStudent.findTelephone("Viettel");

	findStudent.findEmail("gmail.com");
	
	findStudent.findAddress("District 1");
}