Thong tin:
Ten: Luu Truong Duong
MSSV: 19120489
Lop: 19_3 ( ca 2 sang thu 2)

Thay chay ca 3 solution ban che do release x86 ho em nha. May em chay bang x64 va debug bi loi a

-Cach mo file:
1. rebuild solution OopLib o dang release x86
2. copy duong dan release  cua solution OopLib vua nhan duoc chinh sua trong properties
3. rebuild solution MockRepoV1 o dang release x86
4. chinh lai duong dan o  file test2 vao Library, neu khong duoc thi chay 2 file Mock va OopLib release 
5. chinh them ten input OopLib va MockRepoLib
6. f5 o che do release x86

-Tai lieu tham khao: slide bai giang cua thay Quang, file hcmaddress tren j2team

-Danh sach cac yeu cau da lam duoc:
1.Tao ngau nhien n hoc sinh
2.luu thong tin vao file text
3.doc lai file text lay thong tin
4.tim tat ca hoc sinh co thang sinh bat ki
5.tim tat ca hoc sinh dung nha mang bat ki
6.tim tat ca hoc sinh dung email bat ki
7.tim tat ca hoc sinh o Quan bat ki

- Danh sach lam them:
1.Bat buoc Mot so lastname phai di voi middlename nhat dinh
2. thong tin kha chinh xac ve quan va phuong TP HCM
3. chuyen email qua chu thuong, cung cap them domain cho email tu ben ngoai
4. Co the tu can cuoc cong dan cua 1 hoc sinh ma tim ra duoc thong tin co ban cua hoc sinh do qua lenh 
	CitizenMock::info(string citizenID);
5. Han che so tuoi, so tuoi thap nhat la 18 (do sinh vien)

	
